"""
Student Attendance & Examination Engine (SAEE)
A single-file CLI project demonstrating Python Units 1-5.
Only the allowed datetime module is imported.
"""

from datetime import datetime


# ============================================================
# MODULE 1 — STATE CONTROL ENGINE AND TRAJECTORY GUARDS
# ============================================================

def calculate_compound_interest(principal, rate_percent, periods):
    """Calculate compound interest using arithmetic operators only."""
    if principal < 0 or rate_percent < 0 or periods < 0:
        raise OutOfBoundsError("Principal, rate, and periods must be non-negative.")
    rate = rate_percent / 100
    amount = principal
    period = 0
    while period < periods:
        amount = amount * (1 + rate)
        period += 1
    return amount - principal


def calculate_late_penalty(days_late, fee_per_day):
    """Calculate a late-submission penalty using arithmetic operators only."""
    if days_late < 0 or fee_per_day < 0:
        raise OutOfBoundsError("Days late and daily fee must be non-negative.")
    return days_late * fee_per_day


def trajectory_guard(transactions, starting_balance, safety_threshold, terminate=False):
    """Process transactions and stop as soon as a safety or termination condition is met."""
    balance = starting_balance
    processed = 0
    for amount in transactions:
        # Short-circuit evaluation checks the termination flag first.
        if terminate or balance < safety_threshold:
            break
        balance += amount
        processed += 1
        if balance < safety_threshold:
            break
    return balance, processed


def run_command_loop():
    """Run a nested-loop command interface until the explicit EXIT command."""
    print("\nSAEE Command Line")
    print("Commands: HELP, ATTENDANCE, INTEREST, PENALTY, EXIT")
    running = True
    while running:
        command = input("SAEE> ").strip().upper()
        while command == "":
            print("Please enter a command. Type HELP for options.")
            command = input("SAEE> ").strip().upper()
        if command == "EXIT":
            print("Exiting SAEE. Goodbye.")
            running = False
        elif command == "HELP":
            print("HELP: show commands | ATTENDANCE: calculate attendance")
            print("INTEREST: compound-interest demo | PENALTY: late-fee demo | EXIT: quit")
        elif command == "ATTENDANCE":
            try:
                attended = int(input("Classes attended: "))
                total = int(input("Total classes: "))
                if total <= 0 or attended < 0 or attended > total:
                    raise OutOfBoundsError("Attendance counts are outside valid bounds.")
                percentage = attended * 100 / total
                print("Attendance: {:.2f}%".format(percentage))
                if percentage >= 75:
                    print("Eligibility: eligible")
                else:
                    print("Eligibility: attendance shortage")
            except (ValueError, BaseSystemError) as error:
                print("Invalid attendance input:", error)
        elif command == "INTEREST":
            try:
                principal = float(input("Principal: "))
                rate = float(input("Annual rate (%): "))
                periods = int(input("Number of periods: "))
                print("Compound interest:", round(calculate_compound_interest(principal, rate, periods), 2))
            except (ValueError, BaseSystemError) as error:
                print("Invalid interest input:", error)
        elif command == "PENALTY":
            try:
                days = int(input("Days late: "))
                fee = float(input("Fee per day: "))
                print("Penalty:", round(calculate_late_penalty(days, fee), 2))
            except (ValueError, BaseSystemError) as error:
                print("Invalid penalty input:", error)
        else:
            print("Unknown command. Type HELP to see valid commands.")


# ============================================================
# MODULE 2 — NATIVE LOG PARSER AND CLOSURE MECHANICS
# ============================================================

def parse_raw_log_line(line, delimiter=",", quote_char='"'):
    """Parse a delimited log line manually, supporting quoted delimiters and doubled quotes."""
    tokens = []
    current = ""
    in_quotes = False
    index = 0
    field_started = False

    while index < len(line):
        character = line[index]
        if character == quote_char:
            if in_quotes:
                # A doubled quote inside a quoted field represents one literal quote.
                if index + 1 < len(line) and line[index + 1] == quote_char:
                    current += quote_char
                    index += 2
                    field_started = True
                    continue
                in_quotes = False
            elif not field_started and current == "":
                in_quotes = True
            else:
                # Treat a quote in an unquoted field as ordinary data.
                current += character
            field_started = True
        elif character == delimiter and not in_quotes:
            tokens.append(current)
            current = ""
            field_started = False
        else:
            current += character
            field_started = True
        index += 1

    tokens.append(current)
    return tokens


def create_audit_filter(threshold):
    """Create a filter whose independent closure counts accepted audit records."""
    audited_count = 0

    def validate(record):
        """Accept a record when its score meets threshold and update this closure's count."""
        nonlocal audited_count
        try:
            score = float(record[1])
        except (ValueError, TypeError, IndexError):
            return False
        if score >= threshold:
            audited_count += 1
            return True
        return False

    def get_count():
        """Return the number of records accepted by this filter."""
        return audited_count

    validate.get_count = get_count
    return validate


def build_positional_filters(criteria_count):
    """Build positional lambda filters without the loop-variable late-binding bug."""
    filters = []
    index = 0
    while index < criteria_count:
        filters.append(lambda record, k=index: len(record) > k and bool(record[k]))
        index += 1
    return filters


# ============================================================
# MODULE 3 — DATA INVERSION AND IN-PLACE PROCESSING
# ============================================================

def build_service_reverse_index(raw_db):
    """Build service-tag -> sorted unique (account, branch) tuples with a comprehension."""
    return {
        service: sorted({
            (account_id, branch_id)
            for branch_id, accounts in raw_db.items()
            for account_id, services in accounts
            for tag in services
            for service in [tag]
        })
        for service in {
            tag
            for accounts in raw_db.values()
            for account_id, services in accounts
            for tag in services
        }
    }


def clean_transaction_queue(data_list):
    """Clean a heterogeneous list in place without replacing the top-level list object."""
    index = 0
    while index < len(data_list):
        item = data_list[index]

        if isinstance(item, tuple):
            data_list[index] = list(item)
            item = data_list[index]

        if isinstance(item, set):
            even_values = set()
            for value in item:
                if isinstance(value, int) and value % 2 == 0:
                    even_values.add(value)
            data_list[index] = item - even_values
        elif isinstance(item, list):
            item.sort(reverse=True)
        index += 1

    # Remove duplicate primitive values by scanning and deleting by index.
    # Lists, sets, and tuples are containers and are not considered primitive values.
    index = 0
    while index < len(data_list):
        current = data_list[index]
        if isinstance(current, (str, int, float, bool, bytes, type(None))):
            later_index = index + 1
            while later_index < len(data_list):
                if type(data_list[later_index]) == type(current) and data_list[later_index] == current:
                    del data_list[later_index]
                else:
                    later_index += 1
        index += 1
    return data_list


# ============================================================
# MODULE 4 — TRANSACTIONAL FILE MODIFIER AND ERROR LOGGER
# ============================================================

class BaseSystemError(Exception):
    """Base exception for SAEE application errors."""


class CorruptedRecordError(BaseSystemError):
    """Raised when a stored student record is malformed."""


class OutOfBoundsError(BaseSystemError):
    """Raised when a supplied value falls outside permitted bounds."""


class InsufficientBalanceError(BaseSystemError):
    """Reused as a general insufficient-eligibility/credit error in this teaching demo."""


def append_audit_entry(path, message):
    """Append one timestamped audit entry to a plain-text file."""
    with open(path, "a", encoding="utf-8") as file:
        file.write("{} | {}\n".format(datetime.now().isoformat(timespec="seconds"), message))


def validate_student_record(line):
    """Validate a student database line: roll,name,course,attendance,total,marks."""
    fields = parse_raw_log_line(line.rstrip("\n"))
    if len(fields) != 6:
        raise CorruptedRecordError("Expected 6 fields, received {}.".format(len(fields)))
    roll = fields[0].strip()
    name = fields[1].strip()
    course = fields[2].strip()
    try:
        attended = int(fields[3])
        total = int(fields[4])
        marks = float(fields[5])
    except ValueError:
        raise CorruptedRecordError("Attendance and marks must be numeric.")
    if not roll or not name or not course:
        raise CorruptedRecordError("Roll number, name, and course cannot be empty.")
    if total < 0 or attended < 0 or attended > total or marks < 0 or marks > 100:
        raise OutOfBoundsError("Attendance or marks are outside valid bounds.")
    if total == 0 and attended != 0:
        raise OutOfBoundsError("Attended classes cannot exceed a zero total.")
    return {
        "roll": roll, "name": name, "course": course,
        "attended": attended, "total": total, "marks": marks
    }


def update_line_in_place(path, target_line_number, replacement):
    """Replace one ASCII-compatible text record in r+ mode, shifting the tail in chunks."""
    if target_line_number < 1:
        raise OutOfBoundsError("Line numbers start at 1.")
    processed = 0
    rejected = 0
    try:
        with open(path, "r+", encoding="utf-8", newline="") as file:
            line_number = 0
            target_start = None
            target_end = None
            while True:
                line_start = file.tell()
                line = file.readline()
                if line == "":
                    break
                line_number += 1
                if line_number == target_line_number:
                    target_start = line_start
                    target_end = file.tell()
                    original = line
                    break

            if target_start is None:
                raise OutOfBoundsError("Requested line does not exist.")

            if not replacement.endswith("\n"):
                replacement += "\n"
            old_length = len(original)
            new_length = len(replacement)
            delta = new_length - old_length
            tail_start = target_end
            file.seek(0, 2)
            file_end = file.tell()

            if delta > 0:
                # Move the tail backwards in chunks so data is not overwritten.
                read_end = file_end
                chunk_size = 1024
                while read_end > tail_start:
                    chunk_start = read_end - chunk_size
                    if chunk_start < tail_start:
                        chunk_start = tail_start
                    file.seek(chunk_start)
                    chunk = file.read(read_end - chunk_start)
                    file.seek(chunk_start + delta)
                    file.write(chunk)
                    read_end = chunk_start
            elif delta < 0:
                # Move the tail forwards in chunks when the replacement is shorter.
                read_position = tail_start
                write_position = target_start + new_length
                chunk_size = 1024
                while read_position < file_end:
                    file.seek(read_position)
                    chunk = file.read(chunk_size)
                    if chunk == "":
                        break
                    file.seek(write_position)
                    file.write(chunk)
                    read_position += len(chunk)
                    write_position += len(chunk)

            file.seek(target_start)
            file.write(replacement)
            file.truncate()
            processed = 1
            append_audit_entry("ledger.txt", "Updated line {} in {}".format(target_line_number, path))
    except (BaseSystemError, OSError, UnicodeError) as error:
        rejected = 1
        append_audit_entry("corrupted.log", "Line {} rejected: {}".format(target_line_number, error))
        print("Record update failed:", error)
    else:
        print("Record update completed.")
    finally:
        print("File update summary: processed={}, rejected={}".format(processed, rejected))
    return processed == 1


def process_student_file(path):
    """Validate each student record, log invalid lines, and print processed/rejected counts."""
    processed = 0
    rejected = 0
    try:
        with open(path, "r", encoding="utf-8") as file:
            for line_number, line in enumerate(file, 1):
                if not line.strip():
                    continue
                try:
                    record = validate_student_record(line)
                except BaseSystemError as error:
                    rejected += 1
                    append_audit_entry("corrupted.log", "Line {} rejected: {}".format(line_number, error))
                else:
                    processed += 1
                    append_audit_entry("ledger.txt", "Validated student {}".format(record["roll"]))
    except OSError as error:
        rejected += 1
        append_audit_entry("corrupted.log", "File error: {}".format(error))
        print("Could not process student file:", error)
    finally:
        print("Student file summary: processed={}, rejected={}".format(processed, rejected))
    return processed, rejected


# ============================================================
# MODULE 5 — OOP AND POLYMORPHIC EXAMINATION ENGINE
# ============================================================

class Student:
    """Base student class with encapsulated marks and attendance data."""
    total_students = 0

    def __init__(self, roll_number, name, course, attended=0, total_classes=0, marks=0):
        """Create a student after validating the public properties."""
        self._roll_number = roll_number
        self.name = name
        self.course = course
        self.__marks = 0.0
        self._attended = 0
        self._total_classes = 0
        self.marks = marks
        self.total_classes = total_classes
        self.attended = attended
        Student.total_students += 1

    @property
    def roll_number(self):
        """Return the student's roll number."""
        return self._roll_number

    @property
    def marks(self):
        """Return the private examination marks."""
        return self.__marks

    @marks.setter
    def marks(self, value):
        """Validate and set marks between 0 and 100."""
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise TypeError("Marks must be numeric.")
        if value < 0 or value > 100:
            raise OutOfBoundsError("Marks must be between 0 and 100.")
        self.__marks = float(value)

    @property
    def attended(self):
        """Return the number of classes attended."""
        return self._attended

    @attended.setter
    def attended(self, value):
        """Validate and set attended class count."""
        if not isinstance(value, int) or isinstance(value, bool):
            raise TypeError("Attended classes must be an integer.")
        if value < 0:
            raise OutOfBoundsError("Attended classes cannot be negative.")
        if hasattr(self, "_total_classes") and value > self._total_classes:
            raise OutOfBoundsError("Attended classes cannot exceed total classes.")
        self._attended = value

    @property
    def total_classes(self):
        """Return the total scheduled classes."""
        return self._total_classes

    @total_classes.setter
    def total_classes(self, value):
        """Validate total classes and maintain attendance consistency."""
        if not isinstance(value, int) or isinstance(value, bool):
            raise TypeError("Total classes must be an integer.")
        if value < 0:
            raise OutOfBoundsError("Total classes cannot be negative.")
        if hasattr(self, "_attended") and value < self._attended:
            raise OutOfBoundsError("Total classes cannot be less than attended classes.")
        self._total_classes = value

    def attendance_percentage(self):
        """Calculate attendance percentage without using helper reduction functions."""
        if self._total_classes == 0:
            return 0.0
        return self._attended * 100 / self._total_classes

    def process_result(self):
        """Return a basic result dictionary; subclasses can customize the policy."""
        percentage = self.attendance_percentage()
        return {
            "roll": self.roll_number,
            "name": self.name,
            "marks": self.marks,
            "attendance": percentage,
            "grade": self._grade_for_marks(),
            "status": "PASS" if self.marks >= 40 else "FAIL"
        }

    def _grade_for_marks(self):
        """Return a grade based on marks."""
        if self.marks >= 90:
            return "A+"
        if self.marks >= 80:
            return "A"
        if self.marks >= 70:
            return "B"
        if self.marks >= 60:
            return "C"
        if self.marks >= 40:
            return "D"
        return "F"


class RegularStudent(Student):
    """Regular students need 75% attendance to be examination-eligible."""

    def __init__(self, roll_number, name, course, attended=0, total_classes=0, marks=0):
        """Initialize through super() without hardcoding the parent constructor."""
        super().__init__(roll_number, name, course, attended, total_classes, marks)

    def process_result(self):
        """Apply the standard attendance eligibility rule."""
        result = super().process_result()
        if result["attendance"] < 75:
            result["status"] = "NOT ELIGIBLE"
        return result


class SportsStudent(Student):
    """Sports students receive a lower attendance threshold of 65%."""

    def __init__(self, roll_number, name, course, attended=0, total_classes=0, marks=0):
        """Initialize through super() without hardcoding the parent constructor."""
        super().__init__(roll_number, name, course, attended, total_classes, marks)

    def process_result(self):
        """Apply the sports-student attendance threshold."""
        result = super().process_result()
        if result["attendance"] < 65:
            result["status"] = "NOT ELIGIBLE"
        return result


class ScholarshipStudent(Student):
    """Scholarship students must meet 80% attendance and 60 marks."""

    def __init__(self, roll_number, name, course, attended=0, total_classes=0, marks=0):
        """Initialize through super() without hardcoding the parent constructor."""
        super().__init__(roll_number, name, course, attended, total_classes, marks)

    def process_result(self):
        """Apply the scholarship attendance and marks requirements."""
        result = super().process_result()
        if result["attendance"] < 80 or result["marks"] < 60:
            result["status"] = "NOT ELIGIBLE"
        return result


def execute_batch_result_processing(student_list):
    """Process students polymorphically and isolate failures per student."""
    successes = []
    failures = []
    for student in student_list:
        try:
            result = student.process_result()
        except (BaseSystemError, TypeError, ValueError) as error:
            failures.append((getattr(student, "roll_number", "UNKNOWN"), str(error)))
            print("Result failed for student:", error)
        else:
            successes.append(result)
            print("{}: {} ({})".format(result["roll"], result["status"], result["grade"]))
    print("Batch result summary: successes={}, failures={}".format(len(successes), len(failures)))
    return successes, failures


# ============================================================
# DEMONSTRATION CODE — exercises the required features
# ============================================================

def run_demonstrations():
    """Demonstrate each major requirement before starting the interactive CLI."""
    print("=" * 65)
    print("STUDENT ATTENDANCE & EXAMINATION ENGINE (SAEE) — DEMO")
    print("=" * 65)

    print("\n[Unit 1] Compound interest:", round(calculate_compound_interest(1000, 5, 2), 2))
    print("[Unit 1] Late penalty:", calculate_late_penalty(3, 25))
    balance, count = trajectory_guard([100, -50, -1000, 20], 500, 100, False)
    print("[Unit 1] Trajectory guard balance={}, processed={}".format(balance, count))
    balance2, count2 = trajectory_guard([100, 200], 500, 100, True)
    print("[Unit 1] Termination flag guard balance={}, processed={}".format(balance2, count2))

    print("\n[Unit 2] Manual parser:", parse_raw_log_line('S101,"Asha, Patel","She said ""hello""",Present,'))
    audit_a = create_audit_filter(60)
    audit_b = create_audit_filter(80)
    print("[Unit 2] Audit filter:", audit_a(["S101", "75"]), audit_a(["S102", "40"]), "count=", audit_a.get_count())
    print("[Unit 2] Independent filter count:", audit_b.get_count())
    filters = build_positional_filters(3)
    print("[Unit 2] Lambda positions:", [filters[i](["S1", "yes", "ok"]) for i in range(3)])

    print("\n[Unit 3] Reverse index:")
    raw_db = {
        "BRANCH_01": [("S101", {"MATH", "SCIENCE"}), ("S102", {"ENGLISH", "MATH"})],
        "BRANCH_02": [("S101", {"SCIENCE", "SPORTS"}), ("S103", {"MATH", "SPORTS"})]
    }
    print(build_service_reverse_index(raw_db))
    queue = [(1, 2), {1, 2, 3, 4, 5}, [3, 1, 9], "ok", "ok", 7, 7]
    original_id = id(queue)
    clean_transaction_queue(queue)
    print("[Unit 3] In-place queue:", queue, "same id:", id(queue) == original_id)

    print("\n[Unit 4] Custom exception inheritance:")
    print("issubclass checks:", issubclass(CorruptedRecordError, BaseSystemError),
          issubclass(OutOfBoundsError, BaseSystemError),
          issubclass(InsufficientBalanceError, BaseSystemError))
    try:
        validate_student_record("BROKEN,ONLY,TWO")
    except BaseSystemError as error:
        print("Base exception caught:", error)

    print("\n[Unit 5] Encapsulation, inheritance and polymorphism:")
    student = RegularStudent("S101", "Asha Patel", "IT", 40, 50, 88)
    print("Public marks getter:", student.marks)
    print("Name-mangled demonstration value:", student._Student__marks)
    try:
        print(student.__marks)
    except AttributeError:
        print("Direct student.__marks access correctly fails.")
    students = [
        RegularStudent("S101", "Asha Patel", "IT", 40, 50, 88),
        SportsStudent("S102", "Ravi Shah", "IT", 34, 50, 72),
        ScholarshipStudent("S103", "Mina Desai", "IT", 45, 50, 91),
        RegularStudent("S104", "Dev Parmar", "IT", 20, 50, 35)
    ]
    execute_batch_result_processing(students)

    print("\n[Unit 4] File validation and logs:")
    process_student_file("students.db")
    print("\nDemo complete. The interactive command loop starts now.")


if __name__ == "__main__":
    run_demonstrations()
    run_command_loop()

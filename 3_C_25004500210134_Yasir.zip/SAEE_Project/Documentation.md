# Student Attendance & Examination Engine (SAEE)

## 1. Project overview

**SAEE** is a command-line Python project for recording student information, attendance, and examination marks. It calculates attendance percentages and results, validates text-file records, records accepted and rejected operations in audit logs, and demonstrates inheritance and polymorphism.

This is a teaching project, not a production student information system. It uses plain-text files and has no network, GUI, or database engine.

## 2. Deliverables

- `main.py` — complete program, demonstrations, and interactive command loop.
- `Documentation.md` — architecture, design notes, and compliance checklist.
- `students.db` — sample student records.
- `attendance.db` — sample attendance log lines.
- `exam_records.db` — sample examination records.
- `ledger.txt` — accepted/updated-operation audit log (created/extended at runtime).
- `corrupted.log` — rejected-record/error log (created/extended at runtime).

## 3. Requirements and operating instructions

- Python 3.x interpreter.
- No pip installation is needed.
- The only import in `main.py` is `datetime`, which is allowed by the assignment.
- Keep the program and data files in the same working directory.
- Run: `python main.py`
- The program first runs demonstrations, then opens the CLI.
- CLI commands: `HELP`, `ATTENDANCE`, `INTEREST`, `PENALTY`, `EXIT`.

## 4. Main features

1. Nested-loop CLI with clear invalid-command messages.
2. Compound-interest and late-penalty calculations using arithmetic operators.
3. Early-stop trajectory guard using short-circuit logic.
4. Hand-written delimited-line parser with quoted delimiters, doubled quotes, empty fields, and trailing delimiters.
5. Closure-based audit counter using `nonlocal`.
6. Lambda filters with `k=index` default binding to prevent late binding.
7. Reverse index built with dictionary/set comprehensions.
8. In-place heterogeneous queue cleaning while preserving the outer list identity.
9. Custom exception hierarchy.
10. Text-file validation and timestamped logs.
11. In-place record replacement in `r+` mode using chunk-based tail shifting.
12. Student class hierarchy with private marks, protected-style attributes, properties, and polymorphic result policies.
13. Batch result processing catches each student's error independently.

## 5. Architecture diagram

```text
                     +---------------------------+
                     |        main.py / CLI      |
                     +-------------+-------------+
                                   |
            +----------------------+----------------------+
            |                      |                      |
   +--------v--------+    +--------v--------+    +--------v--------+
   | Unit 1: Control |    | Unit 2: Parser  |    | Unit 3: Data    |
   | loops/calcs     |    | closures/lambdas|    | inversion/queue |
   +-----------------+    +-----------------+    +-----------------+
            |                      |                      |
            +----------------------+----------------------+
                                   |
                         +---------v----------+
                         | Unit 4: File engine|
                         | validation/audits |
                         +---------+----------+
                                   |
                         +---------v----------+
                         | Unit 5: Student OOP|
                         | inheritance/results|
                         +--------------------+

 Files: students.db, attendance.db, exam_records.db,
        ledger.txt, corrupted.log
```

## 6. Class diagram

```text
                  +------------------------+
                  |        Student         |
                  +------------------------+
                  | total_students         |
                  | _roll_number           |
                  | _attended               |
                  | _total_classes          |
                  | __marks                 |
                  +------------------------+
                  | marks / attendance      |
                  | attendance_percentage() |
                  | process_result()        |
                  +-----------+------------+
                              |
             +----------------+----------------+
             |                |                |
    +--------v-------+ +------v---------+ +----v----------------+
    | RegularStudent | | SportsStudent  | | ScholarshipStudent |
    +----------------+ +----------------+ +--------------------+
    | 75% threshold  | | 65% threshold  | | 80% + 60 marks     |
    +----------------+ +----------------+ +--------------------+

BaseSystemError
    +-- CorruptedRecordError
    +-- OutOfBoundsError
    +-- InsufficientBalanceError
```

## 7. Data formats

### `students.db`

One record per line with six comma-separated fields:

`roll_number,name,course,classes_attended,total_classes,marks`

Example:

`S101,Asha Patel,IT,40,50,88`

Malformed records are logged to `corrupted.log`. Validated records are logged to `ledger.txt`.

### `attendance.db`

Example:

```text
S101,2026-10-01,PRESENT
S102,2026-10-01,ABSENT
S103,2026-10-01,PRESENT
```

### `exam_records.db`

Example:

```text
S101,Python,88
S102,Python,72
S103,Python,91
```

The sample attendance and exam files are supporting sample data. The main demonstration uses the unified `students.db` record format to validate attendance and marks together.

## 8. Important design decisions

### Unit 1 — state and control

- The CLI uses a `while` loop nested around an input-validation loop.
- Interest is computed by repeated multiplication using arithmetic operators.
- Penalty is calculated by multiplication.
- The trajectory guard stops when the termination flag is true or the balance is below the safety threshold.

### Unit 2 — parser and closures

- `parse_raw_log_line()` manually walks through each character. It does not use `split()` or `replace()`.
- A delimiter inside quotes is preserved as data.
- A doubled quote inside a quoted field becomes one literal quote.
- Empty fields and a final delimiter are retained.
- Each call to `create_audit_filter()` owns its own counter; `nonlocal` updates that counter.
- `build_positional_filters()` binds `index` to `k` at lambda creation time.

### Unit 3 — inversion and in-place queue

- `build_service_reverse_index()` maps each service tag to alphabetically sorted, unique `(student_id, branch_id)` pairs.
- `clean_transaction_queue()` modifies the existing top-level list, converts tuple elements to lists, removes even integers from set elements, sorts embedded lists descending, and removes duplicate primitive values in first-occurrence order.
- The demonstration compares `id(queue)` before and after the call.

### Unit 4 — file handling and exceptions

- `BaseSystemError` is the parent of the three custom exceptions.
- Invalid records are logged with line numbers to `corrupted.log`.
- Validated records and updates are logged to `ledger.txt`.
- `process_student_file()` demonstrates `try-except-else-finally`.
- `update_line_in_place()` opens a text file with `r+`, locates a record with `tell()` and `seek()`, shifts the remaining content in chunks, writes the replacement, and calls `truncate()`.

**Practical limitation:** The chunk-shifting implementation is intended for the assignment's simple text records, whose content and replacement are ASCII-compatible. Python text-mode offsets are not general byte offsets for arbitrary Unicode content. For unrestricted Unicode records, a binary-mode design with explicit UTF-8 encoding would be safer, but the assignment specifically requests `r+`.

### Unit 5 — object-oriented result processing

- `Student` stores marks in private `__marks`.
- `_roll_number`, `_attended`, and `_total_classes` are protected-by-convention attributes.
- Properties validate input types and ranges.
- `RegularStudent`, `SportsStudent`, and `ScholarshipStudent` override `process_result()`.
- `execute_batch_result_processing()` calls the same method polymorphically and isolates errors per student.
- The demonstration reads the name-mangled `_Student__marks` value and shows that direct `student.__marks` access raises `AttributeError`.

## 9. State and scope tracking table

| State kind | Example | Purpose |
|---|---|---|
| Module/global scope | Function and class definitions only | No mutable global state is used to pass closure data |
| Local variable | `index` in parser or queue cleaner | Exists only during the function call |
| Nonlocal variable | `audited_count` in `create_audit_filter()` | Persists between calls to one returned filter |
| Default-argument binding | `k=index` in lambda | Preserves each loop iteration's positional index |
| Private/name-mangled attribute | `Student.__marks` | Python internally stores it as `_Student__marks` |
| Protected-by-convention attribute | `Student._attended` | Signals intended internal/subclass use |
| Class attribute | `Student.total_students` | Counts constructed student objects |

## 10. Unit compliance checklist

| Requirement | Implementation / demonstration |
|---|---|
| Nested command loop and explicit exit | `run_command_loop()` |
| Arithmetic-only interest and penalty | `calculate_compound_interest()`, `calculate_late_penalty()` |
| Short-circuit trajectory guard | `trajectory_guard()` |
| Hand-written quoted parser | `parse_raw_log_line()` |
| Closure with `nonlocal` counter | `create_audit_filter()` |
| Lambda late-binding fix | `build_positional_filters()` |
| Comprehension reverse index | `build_service_reverse_index()` |
| In-place list identity preserved | `clean_transaction_queue()` demo |
| Custom exception hierarchy | Three subclasses of `BaseSystemError` |
| File line validation and logs | `process_student_file()` |
| `r+`, `tell()`, `seek()`, chunk shifting, `truncate()` | `update_line_in_place()` |
| `try-except-else-finally` | File processing functions |
| Encapsulation and name mangling | `Student.marks` property and demo |
| `super()` in subclass constructors | All three student subclasses |
| Polymorphic batch and isolated errors | `execute_batch_result_processing()` |
| Docstrings | Every class and function has a docstring |

## 11. Testing guide

When running `python main.py`, check that the output demonstrates:
- interest and late penalty values;
- early stopping for the safety threshold and termination flag;
- quoted comma, doubled quote, and trailing empty parser field;
- independent audit-filter counters;
- each lambda testing its own position;
- a reverse service index;
- unchanged queue identity after cleaning;
- custom exception inheritance;
- name mangling and direct-access failure;
- mixed student result policies;
- processed/rejected file counts.

To test the interactive interface, enter `HELP`, then try `ATTENDANCE`, `INTEREST`, `PENALTY`, an invalid command, and finally `EXIT`.

## 12. Scope note

SAEE is a small educational prototype. It does not authenticate users, encrypt records, provide multi-user locking, or replace a real student information system. The sample files should be kept as plain-text practice data only.
